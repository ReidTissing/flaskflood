"""
Target Descriptors
"""

from __future__ import print_function, division, absolute_import


class TargetDescriptor(object):
    pass
